// EECalcCore
