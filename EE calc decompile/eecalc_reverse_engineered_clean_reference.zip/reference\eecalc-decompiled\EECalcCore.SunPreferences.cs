// EECalcCore.SunPreferences
