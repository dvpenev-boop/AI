// EECalcCore.Preferences
